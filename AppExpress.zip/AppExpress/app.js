const express = require('express');
const path =  require('path');
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/AppExpress');
const bodyParser = require('body-parser');
let db = mongoose.connection;

db.once('open', function(){
    console.log('connected to database');
})

db.on('error', function(err){
    console.log(err);
})

//Init
const app = express();

let Article = require('./model/article')

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'public')));


//ROUTING HOME

app.get('/', function(req, res){
    Article.find({}, function(err,articles){
if(err)
{
    console.log(err);
}
else{
    res.render('index',{
        title : 'Articles',
        Add : 'Add article',
        articles :  articles
    });
}
       

    });
    
    
});

app.get('/article/:id', function(req, res){
    Article.findById(req.params.id, function(err, article){
        res.render('article',{
            article: article
        })
    })
})

app.get('/add_article/add', function(req, res){
    res.render('add_article',{
        title: 'Add article'
    })
})

//post submit request

app.post('/add', function(req, res){
   var article = new Article();
    article.title = req.body.title;
    article.author = req.body.author;
    article.body = req.body.body;

    article.save(function(err){
        if(err){
            console.log(err);
            return;
        }
        else{
            res.redirect('/')
        }
    })
})


//starting server on port 3000
app.listen('3000', function(){
    console.log('starting server on port number 3000');
})